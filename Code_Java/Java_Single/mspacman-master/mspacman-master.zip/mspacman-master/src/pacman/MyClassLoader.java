package pacman;

public class MyClassLoader extends ClassLoader {

}
