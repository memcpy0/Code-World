package org.itstack.interview;

public class UserApi implements IUserApi {

    public String queryUserInfo() {
        return "小傅哥，公众号：bugstack虫洞栈 | 沉淀、分享、成长，让自己和他人都能有所收获！";
    }

}
