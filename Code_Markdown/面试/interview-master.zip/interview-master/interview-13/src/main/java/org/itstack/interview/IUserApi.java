package org.itstack.interview;

public interface IUserApi {

    String queryUserInfo();

}
