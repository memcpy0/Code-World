package org.itstack.interview;
//this is a interface for bind uid to ThreadID
public interface IBeforeAdvice {
	void beforeAdvice(int uid);
}
