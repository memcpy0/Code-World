package org.itstack.interview.组合关系;

/**
 * 博客：https://bugstack.cn - 沉淀、分享、成长，让自己和他人都能有所收获！
 * 公众号：bugstack虫洞栈
 * Create by 小傅哥(fustack) @2020
 */
public class 结婚证 {

    private 赵玉田 男方;
    private 刘英 女方;

    public void set男方(赵玉田 男方) {
        this.男方 = 男方;
    }

    public void set女方(刘英 女方) {
        this.女方 = 女方;
    }
}
