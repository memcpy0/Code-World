package org.itstack.interview.test;

public class ApiTest {

    public static void main(String[] args) {
        System.out.println("hi!");
    }

}
