package org.itstack.interview.test;

import java.util.HashMap;
import java.util.Map;

public class ApiTest {

    public static void main(String[] args) {
        Map<String, String> map = new HashMap<String, String>(5000);
        System.out.println(map);
    }

}
