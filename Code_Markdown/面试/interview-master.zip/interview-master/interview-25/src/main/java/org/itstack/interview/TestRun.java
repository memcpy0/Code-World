package org.itstack.interview;

public class TestRun {

    public static void main(String[] args) throws InterruptedException {
        Thread.sleep(100000000);
    }

}
