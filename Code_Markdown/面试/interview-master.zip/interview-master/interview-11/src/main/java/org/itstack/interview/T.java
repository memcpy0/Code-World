package org.itstack.interview;

public class T
        implements java.io.Serializable, Comparable<String>, CharSequence {


    public int length() {
        return 0;
    }

    public char charAt(int index) {
        return 0;
    }

    public CharSequence subSequence(int start, int end) {
        return null;
    }

    public int compareTo(String o) {
        return 0;
    }
}
