package org.itstack.interview;

public class MyAspect {

    public void before() {
        System.out.println("前置增强处理...");
    }

}
